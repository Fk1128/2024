package kkk.kakaka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KakakaApplicationTests {

	@Test
	void contextLoads() {
	}

}
