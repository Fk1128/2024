package com.test1.Todo123;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Todo123Application {

	public static void main(String[] args) {
		SpringApplication.run(Todo123Application.class, args);
	}

}
