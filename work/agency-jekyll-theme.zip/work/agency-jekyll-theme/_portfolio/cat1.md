---
caption: #what displays in the portfolio grid:
  title: 고양이얼굴
  subtitle: 눈이맑다
  thumbnail: assets/img/portfolio/04-thumbnail.jpg
  
#what displays when the item is clicked:
title: Title
subtitle: subtitle lorem ipsum dolor sit amet consectetur.
image: assets/img/portfolio/04-thumbnail.jpg #main image, can be a link or a file in assets/img/portfolio
alt: image alt text

---
Use this area to describe your project. **Markdown** supported.

optional info list (delete if not using):

{:.list-inline} 
- Date: 
- Client: 
- Category: 

